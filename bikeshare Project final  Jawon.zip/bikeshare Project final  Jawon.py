from colorama import Fore, Style, init
import pandas as pd
import time
from tabulate import tabulate  # For table formatting

# Initialize colorama for colored output
init(autoreset=True)

# Data files
CITY_DATA = {
    'chicago': 'chicago.csv',
    'new york city': 'new_york_city.csv',
    'washington': 'washington.csv'
}

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.
    """
    print(Fore.YELLOW + "Let’s explore some US bikeshare data!" + Style.RESET_ALL)

    # Get user input for city
    while True:
        city = input(Fore.CYAN + "Enter city (Chicago, New York City, Washington): " + Style.RESET_ALL).strip().lower()
        if city in CITY_DATA:
            break
        else:
            print(Fore.RED + "Umm sorry, try again. Please choose from ['chicago', 'new york city', 'washington']." + Style.RESET_ALL)

    # Get user input for month
    while True:
        month = input(Fore.CYAN + "Enter month (January, February, ..., June) or 'all': " + Style.RESET_ALL).strip().title()
        if month in ['January', 'February', 'March', 'April', 'May', 'June', 'All']:
            break
        else:
            print(Fore.RED + "Umm sorry, try again. Please enter a valid month or 'all'." + Style.RESET_ALL)

    # Get user input for day of week
    while True:
        day = input(Fore.CYAN + "Enter day of week (Monday, Tuesday, ..., Sunday) or 'all': " + Style.RESET_ALL).strip().title()
        if day in ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'All']:
            break
        else:
            print(Fore.RED + "Umm sorry, try again. Please enter a valid day or 'all'." + Style.RESET_ALL)

    print(Fore.GREEN + f"\nFilters applied: City = {city.title()}, Month = {month}, Day = {day}" + Style.RESET_ALL)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.
    """
    # Load data into a DataFrame
    df = pd.read_csv(CITY_DATA[city])

    # Convert Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    # Extract month, day, and hour from Start Time
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.day_name()
    df['hour'] = df['Start Time'].dt.hour

    # Filter by month
    if month != 'All':
        months = ['January', 'February', 'March', 'April', 'May', 'June']
        month_index = months.index(month) + 1
        df = df[df['month'] == month_index]

    # Filter by day of week
    if day != 'All':
        df = df[df['day_of_week'] == day]

    return df


def display_table(df):
    """
    Displays the first 5 rows of the data in a tabular format.
    """
    print(Fore.LIGHTCYAN_EX + "\nDisplaying Raw Data as Table..." + Style.RESET_ALL)
    print(tabulate(df.head(5), headers='keys', tablefmt='pretty'))
    print(Fore.LIGHTCYAN_EX + "-" * 50 + Style.RESET_ALL)


def advanced_questions(df):
    """
    Allows the user to ask additional questions dynamically.
    """
    questions = {
        1: "What is the total number of trips?",
        2: "What is the most common trip duration?",
        3: "What is the percentage of trips during peak hours (7-9 AM and 5-7 PM)?",
        4: "What is the least busy station?",
        5: "How many trips started and ended at the same station?",
    }

    while True:
        print(Fore.LIGHTYELLOW_EX + "\nAdvanced Questions Menu:" + Style.RESET_ALL)
        for key, question in questions.items():
            print(f"{key}: {question}")
        print("6: Exit Advanced Questions")

        try:
            choice = int(input(Fore.CYAN + "\nEnter the number of the question you'd like to ask: " + Style.RESET_ALL))
            if choice == 6:
                print(Fore.LIGHTGREEN_EX + "Exiting Advanced Questions Menu.\n" + Style.RESET_ALL)
                break

            if choice not in questions:
                print(Fore.RED + "Invalid choice. Please select a valid option." + Style.RESET_ALL)
                continue

            # Answer the selected question
            if choice == 1:
                print(Fore.CYAN + f"Total Number of Trips: {len(df)}" + Style.RESET_ALL)
            elif choice == 2:
                most_common_duration = df['Trip Duration'].mode()[0]
                print(Fore.CYAN + f"Most Common Trip Duration: {most_common_duration} seconds" + Style.RESET_ALL)
            elif choice == 3:
                peak_trips = df[(df['hour'] >= 7) & (df['hour'] <= 9) | (df['hour'] >= 17) & (df['hour'] <= 19)]
                percentage = (len(peak_trips) / len(df)) * 100
                print(Fore.CYAN + f"Percentage of Trips During Peak Hours: {percentage:.2f}%" + Style.RESET_ALL)
            elif choice == 4:
                least_busy_station = df['Start Station'].value_counts().idxmin()
                print(Fore.CYAN + f"Least Busy Station: {least_busy_station}" + Style.RESET_ALL)
            elif choice == 5:
                same_station_trips = df[df['Start Station'] == df['End Station']].shape[0]
                print(Fore.CYAN + f"Trips Starting and Ending at the Same Station: {same_station_trips}" + Style.RESET_ALL)

        except ValueError:
            print(Fore.RED + "Invalid input. Please enter a number." + Style.RESET_ALL)


def restart_prompt():
    """
    Prompts the user to restart the program or exit.
    """
    while True:
        restart = input(Fore.CYAN + "\nWould you like to restart? Enter yes or no: " + Style.RESET_ALL).strip().lower()
        if restart in ['yes', 'no']:
            return restart
        else:
            print(Fore.RED + "Invalid input. Please enter 'yes' or 'no'." + Style.RESET_ALL)


def main():
    """
    The main function that drives the program.
    """
    print(Fore.LIGHTBLUE_EX + "=" * 60)
    print("             Ultimate Bikeshare Explorer.us!")
    print("=" * 60 + Style.RESET_ALL)
    print(Fore.YELLOW + "Analyze bikeshare trends, fun facts, and unique insights.\n" + Style.RESET_ALL)

    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        if df.empty:
            print(Fore.RED + "No data available for the selected filters. Please try again." + Style.RESET_ALL)
        else:
            display_table(df)
            advanced_questions(df)

        if restart_prompt() == 'no':
            print(Fore.LIGHTGREEN_EX + "Thank you for exploring Bikeshare Data! Have a great day!" + Style.RESET_ALL)
            break


if __name__ == "__main__":
    main()




